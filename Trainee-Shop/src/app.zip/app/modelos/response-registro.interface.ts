export interface ResponsRegistroI{
  clienteId:number;
  nombreCliente:string;
  cedula:string;
  passwordCliente:string;
  direccionCliente:string;
  emailCliente:string;
  celularCliente:string;
}
  