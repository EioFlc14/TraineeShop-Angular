export interface Task {
    idProducto:string;
    nombre_producto:string;
    precio:string;
    unidad:string;
    imagen_producto:string;
    Supermercado_idSupermercado:string;
}
