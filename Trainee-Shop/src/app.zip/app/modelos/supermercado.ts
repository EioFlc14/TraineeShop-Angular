

export class Supermercado {
    idSupermercado: number=0;
    nombre_supermercado: string="";
    cuenta_bancaria: string = "";
    imagen_supermercado: string = "";
}
