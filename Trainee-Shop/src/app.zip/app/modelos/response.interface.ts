export interface ResponseI{
  clienteId:number;
  nombreCliente:string;
  cedula:string;
  direccionCliente:string;
}
