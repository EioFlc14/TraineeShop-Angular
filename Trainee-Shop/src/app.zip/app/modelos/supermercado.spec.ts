import { Supermercado } from './supermercado';

describe('Supermercado', () => {
  it('should create an instance', () => {
    expect(new Supermercado()).toBeTruthy();
  });
});
