export interface LoginI{
  usuario:string;
  password:string;
}
