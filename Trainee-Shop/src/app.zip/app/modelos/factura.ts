export class Factura {
    //idFactura: number = 0;
    total: number = 0.0;
    //subtotal: number = 0.0;
    //metodo_pago: string = "";
    //fecha: string = "";
    //idSupermercado: int = 0;
    //nombre_supermercado: string = "";

}
